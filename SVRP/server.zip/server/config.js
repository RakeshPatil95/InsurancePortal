module.exports = {
    secret: 'rnpdbekspwkrnvnsuwquivhaokspsast',
  }
  